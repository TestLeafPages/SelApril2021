package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods {
	
	public CreateLeadPage(ChromeDriver driver) {
		this.driver = driver;
		
	}
	public CreateLeadPage enterCompanyName(String companyName) {
		driver.findElementById("createLeadForm_companyName").sendKeys(companyName);
		return this;
	}
	
	public CreateLeadPage enterFirstName(String firstName) {
		driver.findElementById("createLeadForm_firstName").sendKeys(firstName);
		return this;
	}
	
	public CreateLeadPage enterLastname(String lastName) {
		driver.findElementById("createLeadForm_lastName").sendKeys(lastName);
		return this;
	}
	
	public ViewLeadPage clickCreteLeadButton() {
		driver.findElementByName("submitButton").click();
		
		return new ViewLeadPage(driver);

	}
	
	

}
