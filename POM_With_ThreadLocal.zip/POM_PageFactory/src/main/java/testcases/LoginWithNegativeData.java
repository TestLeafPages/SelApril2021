package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class LoginWithNegativeData extends ProjectSpecificMethods{
	
	@Test
	public void runLoginAndLogout() throws InterruptedException {
		//create object for the page where first action method id present
		//LoginPage lp = new LoginPage();
		
		
		
		new LoginPage()
		.enterUsername("Demosalesmanager")
		.enterPassword("crmsfa123")
		.clickLoginButtonForNegative();
		//.clickLogoutButton();
	}

}
