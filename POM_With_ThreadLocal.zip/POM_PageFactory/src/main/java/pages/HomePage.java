package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{
	
	
	
	
	public LoginPage clickLogoutButton() {
		getDriver().findElementByClassName("decorativeSubmit").click();
		
		return new LoginPage();
		
	}
	
	public MyHomePage clickCrmsfaLink() {
		getDriver().findElementByLinkText("CRM/SFA").click();
		return new MyHomePage();
	}

}
