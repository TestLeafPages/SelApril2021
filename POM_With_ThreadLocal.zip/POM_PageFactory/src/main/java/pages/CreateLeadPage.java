package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods {
	
	
	public CreateLeadPage enterCompanyName(String companyName) {
		getDriver().findElementById("createLeadForm_companyName").sendKeys(companyName);
		return this;
	}
	
	public CreateLeadPage enterFirstName(String firstName) {
		getDriver().findElementById("createLeadForm_firstName").sendKeys(firstName);
		return this;
	}
	
	public CreateLeadPage enterLastname(String lastName) {
		getDriver().findElementById("createLeadForm_lastName").sendKeys(lastName);
		return this;
	}
	
	public ViewLeadPage clickCreteLeadButton() {
		getDriver().findElementByName("submitButton").click();
		
		return new ViewLeadPage();

	}
	
	

}
