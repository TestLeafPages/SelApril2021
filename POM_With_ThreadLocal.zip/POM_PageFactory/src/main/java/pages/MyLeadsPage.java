package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class MyLeadsPage extends ProjectSpecificMethods {
	
	
	public CreateLeadPage clickCreateLeadLink() {
		getDriver().findElementByLinkText("Create Lead").click();
		return new CreateLeadPage();
	}
}
