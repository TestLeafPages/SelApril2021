package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	
	
	
	
	// actionElementName()
	public LoginPage enterUsername(String uName) throws InterruptedException {
		getDriver().findElementById("username").sendKeys("Demosalesmanager");
		
		return this;
	}

	
	public LoginPage enterPassword(String pWord) {
		getDriver().findElementById("password").sendKeys("crmsfa");
		
		return this;
	}

	
	
	public HomePage clickLoginButton() {
		getDriver().findElementByClassName("decorativeSubmit").click();		
		return new HomePage();
	}
	
	public LoginPage clickLoginButtonForNegative() {
		getDriver().findElementByClassName("decorativeSubmit").click();
					
			return this;
		}
	
	
}
