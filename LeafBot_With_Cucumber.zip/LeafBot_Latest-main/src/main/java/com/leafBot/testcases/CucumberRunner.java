package com.leafBot.testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.leafBot.testng.api.base.ProjectSpecificMethods;

import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.FeatureWrapper;
import io.cucumber.testng.PickleWrapper;
import io.cucumber.testng.TestNGCucumberRunner;
@CucumberOptions(features="src/main/java/features/Login.feature",
				  glue="com.leafBot.pages",
				  monochrome = true)
public class CucumberRunner extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testCaseName = "Login Test using Cucumber";
		testDescription = "Login testCase using cucumber";
		authors = "Hari";
		category = "Smoke";
		nodes = "Login Test";
		
	}
	
	

}
