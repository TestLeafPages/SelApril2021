package com.leafBot.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import io.cucumber.java.en.Then;



public class HomePage extends ProjectSpecificMethods{

	
	@Then("Homepage should be displayed")
	public HomePage verifyHomePage() {
		verifyDisplayed(locateElement("filter"));
		return this;
	}

	

}










