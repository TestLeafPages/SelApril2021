package com.leafBot.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import io.cucumber.java.en.Given;


public class LoginPage extends ProjectSpecificMethods{
	
	
	
	@Given("Enter username as {string}")
	public LoginPage enterUserName(String data) {	
		switchToFrame(0);
		clearAndType(locateElement("user_name"), data);
		return this;
	}	

	@Given("Enter password as {string}")
	public LoginPage enterPassword(String data) {
		clearAndType(locateElement("user_password"), data);
		return this;
	}	
	
	@Given("Click on login button")
	public HomePage clickLogin() {
		click(locateElement("sysverb_login"));
		defaultContent();
		return new HomePage();		
	}
	
	
}
