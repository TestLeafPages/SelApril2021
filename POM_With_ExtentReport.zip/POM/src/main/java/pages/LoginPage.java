package pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
		
		
	}
		public LoginPage enterUsername(String uName) throws InterruptedException, IOException {
		try {
			driver.findElementById("username").sendKeys(uName);
			reportStep("username "+uName+" entered successfully", "pass");
		} catch (Exception e) {
			reportStep("username "+uName+" entered not successfully", "fail");
		}
		return this;
	}

	
	
	public LoginPage enterPassword(String pWord) throws IOException {
		try {
			driver.findElementById("password").sendKeys(pWord);
			reportStep("password "+pWord+" entered successfully", "pass");
		} catch (Exception e) {
			reportStep("password "+pWord+" entered not successfully", "fail");
		}
		return this;
	}

	
	public HomePage clickLoginButton() throws IOException {
		try {
			driver.findElementByClassName("decorativeSubmit").click();
			reportStep("Login button clicked without issue", "pass");
		} catch (Exception e) {
			reportStep("Login button not clicked", "fail");
		}
				
		return new HomePage(driver, node);
	}
	
	public LoginPage clickLoginButtonForNegative() throws IOException {
		try {
			driver.findElementByClassName("decorativeSubmit").click();
			reportStep("Login button clicked without issue", "pass");
		} catch (Exception e) {
			reportStep("Login button not clicked", "fail");
		}
			return this;
		}
	
	
}
