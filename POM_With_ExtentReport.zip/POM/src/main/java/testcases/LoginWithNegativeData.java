package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class LoginWithNegativeData extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setDetails() {
		testName = "LoginAndLogoutForNegative";
		testDescription = "Login test for LeafTaps app with Negative data";
		testCategory = "smoke";
		testAuthor = "Hari";
	}
	
	@Test
	public void runLoginAndLogout() throws InterruptedException, IOException {
		//create object for the page where first action method id present
		//LoginPage lp = new LoginPage();
		
		
		
		new LoginPage(driver,node)
		.enterUsername("Demosalesmanager")
		.enterPassword("crmsfa123")
		.clickLoginButtonForNegative();
		//.clickLogoutButton();
	}

}
