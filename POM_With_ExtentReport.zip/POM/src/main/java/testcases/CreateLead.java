package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setDetails() {
		excelFileName = "CreateLead";
		testName = "CreateLead";
		testDescription = "Create Lead with mandatory informations";
		testCategory = "functional";
		testAuthor = "Hari";
	}
	
	
	@Test(dataProvider = "sendData")
	public void runCreateLead(String username, String password, String company, String fName, String lName) throws InterruptedException, IOException {
				
		new LoginPage(driver,node)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName(company)
		.enterFirstName(fName)
		.enterLastname(lName)
		.clickCreteLeadButton()
		.verifyFirstName();
	}

}
