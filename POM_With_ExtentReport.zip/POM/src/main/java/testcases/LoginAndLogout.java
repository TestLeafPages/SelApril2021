package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setDetails() {
		excelFileName = "Login";
		testName = "LoginAndLogout";
		testDescription = "Login test for LeafTaps app";
		testCategory = "smoke";
		testAuthor = "Hari";
	}
	
	@Test(dataProvider = "sendData")
	public void runLoginAndLogout(String username, String password) throws InterruptedException, IOException {
		//create object for the page where first action method id present
		//LoginPage lp = new LoginPage();
		
		
		
		new LoginPage(driver,node)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton();
		//.clickLogoutButton();
	}

}
