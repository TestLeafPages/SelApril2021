package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	
	  @CacheLookup
	  @FindBy(how=How.CLASS_NAME,using="inputLogin") List<WebElement> eleUsername;
	 
	
	// actionElementName()
	public LoginPage enterUsername(String uName) throws InterruptedException {
		//driver.findElementById("username").sendKeys("Demosalesmanager");
		WebElement ele = eleUsername.get(0);
		ele.sendKeys(uName);
		//Thread.sleep(5000);
		return this;
	}

	@FindBy(how=How.ID,using="password") 
	WebElement elePassword;
	
	public LoginPage enterPassword(String pWord) {
		//driver.findElementById("password").sendKeys("crmsfa");
		elePassword.sendKeys(pWord);
		return this;
	}

	@FindBy(how = How.CLASS_NAME,using="decorativeSubmit") 
	WebElement eleLogin;
	
	public HomePage clickLoginButton() {
	//	driver.findElementByClassName("decorativeSubmit").click();
		eleLogin.click();			
		return new HomePage(driver);
	}
	
	public LoginPage clickLoginButtonForNegative() {
			//driver.findElementByClassName("decorativeSubmit").click();
			eleLogin.click();			
			return this;
		}
	
	
	
	//AND condition
		/*
		 * @FindBys( {
		 * 
		 * @FindBy(how=How.CLASS_NAME,using="inputLogin"),
		 * 
		 * @FindBy(how=How.XPATH,using="//input[@id='username123']") }
		 * 
		 * ) WebElement eleUsername;
		 */
		
		//OR
		/*
		 * @FindAll( {
		 * 
		 * @FindBy(how=How.CLASS_NAME,using="inputLogin"),
		 * 
		 * @FindBy(how=How.XPATH,using="//input[@id='username123']") }
		 * 
		 * ) WebElement eleUsername;
		 */
		

}
