package pages;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
		
	}
	
	
	// actionElementName()
	public LoginPage enterUsername(String uName) throws InterruptedException {
		driver.findElementById("username").sendKeys(uName);
		//Thread.sleep(5000);
		return this;
	}

	public LoginPage enterPassword(String pWord) {
		driver.findElementById("password").sendKeys(pWord);
		return this;
	}

	public HomePage clickLoginButton() {
		driver.findElementByClassName("decorativeSubmit").click();
					
		return new HomePage(driver,prop);
	}

}
